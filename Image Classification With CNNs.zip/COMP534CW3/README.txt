The enclosed file:

	-AppliedAiCW3ClassificationModel.ipynb

Was ran on google collab as to take full advantage of the more powerful CPU.

The version of google collab we used did not come with scikit-plot pre installed and so the first cell in the notebook containing the line 'pip install scikit-plot' is to allow us to run the code on that service with the scikit-plot module.

The 'Chest X-ray (Covid-19 & Pneumonia)' Kaggle dataset given to too large to load each time.
We therefore mounted our respective google drives using the code 'drive.mount('/gdrive')' then added the file paths:
	TrainImage = r'/gdrive/MyDrive/Data/train'
	TestImage = r'/gdrive/MyDrive/Data/test'
Should you wish to run this code yourself simply amend these to the correct file paths.


 